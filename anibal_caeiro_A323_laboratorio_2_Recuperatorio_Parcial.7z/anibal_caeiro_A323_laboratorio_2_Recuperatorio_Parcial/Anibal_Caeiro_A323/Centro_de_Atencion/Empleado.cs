﻿using System;

namespace Centro_de_Atencion
{
    public abstract class Empleado
    {
        protected string legajo;
        protected string nombre;
        protected TimeSpan horaIngreso;
        protected TimeSpan horaEgreso;

        public string Legajo
        {
            get { return legajo; }
        }

        public string Nombre
        {
            get { return nombre; }
        }

        public TimeSpan HoraIngreso
        {
            get { return horaIngreso; }
        }

        public TimeSpan HoraEgreso
        {
            get { return horaEgreso; }
            set { horaEgreso = ValidarHoraEgreso(value); }
        }

        protected Empleado(string legajo, string nombre, TimeSpan horaIngreso)
        {
            this.legajo = legajo;
            this.nombre = nombre;
            this.horaIngreso = horaIngreso;
        }

        private TimeSpan ValidarHoraEgreso(TimeSpan horaEgreso)
        {
            if (horaEgreso > horaIngreso)
            {
                return horaEgreso;
            }
            else
            {
                return DateTime.Now.TimeOfDay;
            }
        }


        public double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours;
        }

        public static bool operator == (Empleado empleado1, Empleado empleado2)
        {
            if (ReferenceEquals(empleado1, empleado2))
            {
                return true;
            }

            if (ReferenceEquals(empleado1, null) || ReferenceEquals(empleado2, null))
            {
                return false;
            }

            return empleado1.Legajo == empleado2.Legajo;
        }

        public static bool operator !=(Empleado empleado1, Empleado empleado2)
        {
            return !(empleado1 == empleado2);
        }
    }
}


