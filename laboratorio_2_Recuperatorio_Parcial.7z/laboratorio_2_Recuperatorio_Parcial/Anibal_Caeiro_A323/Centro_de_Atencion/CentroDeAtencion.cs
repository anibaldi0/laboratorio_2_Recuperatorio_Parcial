﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Centro_de_Atencion
{
    public class CentroDeAtencion
    {
        private int cantRacsPorSuper;
        private List<Empleado> empleados;
        private string nombre;

        public CentroDeAtencion()
        {
            empleados = new List<Empleado>();
        }

        public List<Empleado> Empleados
        {
            get
            {
                return empleados;
            }
        }

        public string Nombre
        {
            get
            {
                return nombre;
            }
        }

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            this.nombre = nombre;
            this.cantRacsPorSuper = cantRacsPorSuper;
            empleados = new List<Empleado>();
        }

        public string ImprimirNomina()
        {
            return nombre;
        }

        private bool ValidaCantidadDeRacs()
        {
            return true;
        }
    }
}
