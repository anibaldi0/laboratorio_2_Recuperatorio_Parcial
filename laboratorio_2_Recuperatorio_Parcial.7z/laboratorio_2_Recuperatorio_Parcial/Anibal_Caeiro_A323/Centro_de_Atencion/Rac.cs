﻿using System;

namespace Centro_de_Atencion
{
    public class Rac : Empleado
    {
        public enum EGrupo
        {
            CALL_IN,
            CALL_OUT,
            RRSS
        }

        private EGrupo grupo;
        private static float valorHora;

        public EGrupo Grupo
        {
            get { return grupo; }
        }

        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso)
        {
            this.grupo = EGrupo.CALL_IN;
        }

        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo)
            : base(legajo, nombre, horaIngreso)
        {
            this.grupo = grupo;
        }

        public string EmitirFactura()
        {
            double importeFacturacion = Facturar();
            return $"Factura de: {ToString()}\nImporte a facturar: {importeFacturacion}";
        }

        private float CalcularBono()
        {
            switch (grupo)
            {
                case EGrupo.CALL_OUT:
                    return 0.1F;
                case EGrupo.RRSS:
                    return 0.2F;
                default:
                    return 0.0F;
            }
        }

        protected virtual double Facturar()
        {
            double totalHorasTrabajadas = (horaEgreso - horaIngreso).TotalHours;
            double bono = CalcularBono();
            return totalHorasTrabajadas * valorHora * (1 + bono);
        }


        public override string ToString()
        {
            return $"{this.GetType().Name} - {grupo} - {legajo} - {nombre}";
        }
    }
}
