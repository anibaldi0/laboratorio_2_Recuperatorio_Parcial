﻿using System;

namespace Centro_de_Atencion
{
    public class Supervisor : Empleado
    {
        private static float valorHora;

        public static float ValorHora
        {
            get { return valorHora; }
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }

        public string EmitirFactura()
        {
            float importeFacturacion = Facturar();
            return $"Factura de: {ToString()}\nImporte a facturar: {importeFacturacion}";
        }

        protected virtual float Facturar()
        {
            float totalHorasTrabajadas = (float)(horaEgreso - horaIngreso).TotalHours;
            return totalHorasTrabajadas * valorHora;
        }

        private Supervisor(string legajo) : base(legajo, "n/a", new TimeSpan(9, 0, 0)) { }

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso) : base(legajo, nombre, horaIngreso) { }


        public static implicit operator string(Supervisor supervisor)
        {
            return $"Supervisor - {supervisor.Legajo} - {supervisor.Nombre}";
        }

        public override string ToString()
        {
            return $"{this.GetType().Name} - {Legajo} - {Nombre}";
        }
    }
}
